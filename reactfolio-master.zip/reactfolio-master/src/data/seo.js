const SEO = [
	{
		page: "home",
		description:
			"¡Bienvenidos a la página oficial de Geronimo Benavides, también conocido como Momo, el programador del momento! 🚀💻¡Hola, mundo! Soy Geronimo, pero muchos me conocen como Momo, y estoy emocionado de compartir mi pasión por la programación contigo. En este espacio, te llevaré a un viaje fascinante a través del código, la tecnología y la creatividad.",
		keywords: ["Tharindu", "Tharindu N", "Tharindu Nayanajith"],
	},

	{
		page: "about",
		description:
			"I am a backend developer with expertise in Node.js. I have experience in building scalable, secure and reliable web applications using various frameworks and technologies.",
		keywords: ["Tharindu", "Tharindu N", "Tharindu Nayanajith"],
	},

	{
		page: "articles",
		description:
			"Chronological collection of my long-form thoughts on programming, leadership, product design, and more.",
		keywords: ["Tharindu", "Tharindu N", "Tharindu Nayanajith"],
	},

	{
		page: "projects",
		description:
			"I've worked o a variety of projects over the years and I'm proud of the progress I've made. Many of these projects are open-source and available for others to explore and contribute to.",
		keywords: ["Tharindu", "Tharindu N", "Tharindu Nayanajith"],
	},

	{
		page: "contact",
		description:
			"If you're interested in collaborating on a project, feel free to reach out to me. I'm always open to new ideas and opportunities.",
		keywords: ["Tharindu", "Tharindu N", "Tharindu Nayanajith"],
	},
];

export default SEO;
