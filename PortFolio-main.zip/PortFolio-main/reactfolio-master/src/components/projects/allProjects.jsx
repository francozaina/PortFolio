import React, { useState, useEffect } from "react";
import Project from "./project";
import INFO from "../../data/user";
import "./styles/allProjects.css";

const AllProjects = () => {
  const [favoritos, setFavoritos] = useState([]);

  useEffect(() => {
    const storedFavoritos = JSON.parse(localStorage.getItem("favoritos")) || [];
    setFavoritos(storedFavoritos);
  }, []);

  const handleAgregarFavorito = (project) => {
    if (!favoritos.some((favProject) => favProject.title === project.title)) {
      const newFavoritos = [...favoritos, project];
      setFavoritos(newFavoritos);
      localStorage.setItem("favoritos", JSON.stringify(newFavoritos));
    }
  };

  const handleEliminarFavorito = (projectTitle) => {
    const newFavoritos = favoritos.filter((project) => project.title !== projectTitle);
    setFavoritos(newFavoritos);
    localStorage.setItem("favoritos", JSON.stringify(newFavoritos));
  };

  return (
    <div className="all-projects-container">
      {INFO.projects.map((project, index) => (
        <div className="all-projects-project" key={index}>
          <Project
            logo={project.logo}
            title={project.title}
            description={project.description}
            linkText={project.linkText}
            link={project.link}
          />
          <div className="button-container">
            <button
              className="add-favorite-button"
              onClick={() => handleAgregarFavorito(project)}
            >
              Agregar a favoritos
            </button>
          </div>
        </div>
      ))}
      <div className="favoritos-container">
        <h2>Proyectos Favoritos</h2>
        {favoritos.map((project, index) => (
          <div key={index}>
            <p>{project.title}</p>
            <div className="button-container">
              <button
                className="remove-favorite-button"
                onClick={() => handleEliminarFavorito(project.title)}
              >
                Eliminar de favoritos
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export { AllProjects };


