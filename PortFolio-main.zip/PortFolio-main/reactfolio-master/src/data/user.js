const INFO = {
	main: {
		title: "Reactfolio by truethari",
		name: "Tharindu N.",
		email: "fran.roman.zeta@gmail.com",
		logo: "../logo.png",
	},

	socials: {
		twitter: "https://twitter.com/",
		github: "https://github.com/",
		linkedin: "https://linkedin.com/",
		instagram: "https://instagram.com/",
		stackoverflow: "https://stackoverflow.com/",
		facebook: "https://facebook.com/",
	},

	homepage: {
		title: "Geronimo ¨Momo¨ Benavides",
		description:
			"¡Bienvenidos a la página oficial de Geronimo Benavides, también conocido como Momo, el programador del momento! 🚀💻 ¡Hola, mundo! Soy Geronimo, pero muchos me conocen como Momo, y estoy emocionado de compartir mi pasión por la programación contigo. En este espacio, te llevaré a un viaje fascinante a través del código, la tecnología y la creatividad.",
	},

	about: {
		title: "Soy Momo!",
		description:
			"Así que, ¿qué onda conmigo y la programación? Les cuento, desde que era un Kevin de Brownie, siempre me llamó la atención el mundo de la compu. Pero un día, me encontré con el señor Tito Calderón del código, y me dije a mí mismo: ¿Por qué no intentar esto de ser un programador, che?. Y aca estamos, codeando como si no hubiera un mañana.",
	},

	articles: {
		title: "Favoritos!",
		description:
			"Estos son los proyectos favoritos de mi carrera!",
	},

	projects: [
		{
			title: "HARDWARE",
			description:
				"Un proyecto para probar funciones de hardware de tu telefono!.",
			logo: "https://cdn.jsdelivr.net/npm/programming-languages-logos/src/javascript/javascript.png",
			linkText: "GitHub",
			link: "https://github.com/francozaina/HARDAWRE",
		},

		{
			title: "APP ORT",
			description:
				"Una aplicacion hecha en react native para usar en el labo de ort!.",
			logo: "https://cdn.jsdelivr.net/npm/programming-languages-logos/src/javascript/javascript.png",
			linkText: "GitHub",
			link: "https://github.com/FedeChediex/Proyecto_Final",
		},

		{
			title: "PERSONAJES",
			description:
				"Un buscador de personajes de peliculas con filtro usando una api de imBD.",
			logo: "https://cdn.jsdelivr.net/npm/programming-languages-logos/src/javascript/javascript.png",
			linkText: "GitHub",
			link: "https://github.com/francozaina/TP-Personajes",
		},
	],
};

export default INFO;
