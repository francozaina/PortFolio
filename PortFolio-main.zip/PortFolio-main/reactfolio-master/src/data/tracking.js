// Google Analytics Tracking ID
// https://github.com/truethari/reactfolio#-google-analytics
export const TRACKING_ID = "";
